from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User
from app.schemas import UserCreate, UserOut, OTPRequest, OTPVerify, LoginRequest, Token
from app.auth import hash_password, verify_password, create_access_token, generate_otp, verify_otp

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def register(payload: UserCreate, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.phone_number == payload.phone_number).first()
    if existing:
        raise HTTPException(status_code=400, detail="Phone number already registered")

    user = User(
        full_name=payload.full_name,
        phone_number=payload.phone_number,
        email=payload.email,
        hashed_password=hash_password(payload.password),
        role=payload.role,
        preferred_language=payload.preferred_language,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/otp/request")
def request_otp(payload: OTPRequest):
    code = generate_otp(payload.phone_number)
    # In production: send via SMS gateway instead of returning it.
    return {"message": "OTP sent", "debug_otp": code}


@router.post("/otp/verify")
def confirm_otp(payload: OTPVerify, db: Session = Depends(get_db)):
    if not verify_otp(payload.phone_number, payload.otp_code):
        raise HTTPException(status_code=400, detail="Invalid or expired OTP")

    user = db.query(User).filter(User.phone_number == payload.phone_number).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    token = create_access_token(user.id, user.role.value)
    return Token(access_token=token)


@router.post("/login", response_model=Token)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.phone_number == payload.phone_number).first()
    if not user or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Incorrect phone number or password")

    token = create_access_token(user.id, user.role.value)
    return Token(access_token=token)
